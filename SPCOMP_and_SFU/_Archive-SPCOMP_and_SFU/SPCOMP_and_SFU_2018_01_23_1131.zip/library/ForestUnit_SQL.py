#-------------------------------------------------------------------------------
# Name:        Forest Unit SQL
#
# Author:      kimdan
#
# Created:     03/11/2017
# Note:
#   This script contains SQL queries for populating standard forest units.
#   Note that the original sql has been altered in several ways:
#       1. Or and By has been replaced with _Or and _By
#       2. Ecosite has been replaced with Ecosite1.
#       3. wild card - % - has been added for ecosite sqls
#
#   Document used for these sqls are saved here:
#   \\lrcpsoprfp00001\MNR_NER\GI_MGMT\Tools\Scripts\FMPTools_2017\Landbase_SFU_Checker\Documents\FU
#-------------------------------------------------------------------------------



NER_Boreal_SFU = {

# fields required: POLYTYPE, Ecosite_GeoRangeAndNumber and either OSC or SC

#   |Order   |SFU        |SQL                   |SQL addition if Ecosite incorporated

    1:  ['PR1',     """ "Pr">= 70 """, ""],
    2:  ['PW1',     """ "Pw" + "Pr" + ("Sw" + "Sx") + "He" >= 40 And "Pw" >= 30 """, ""],
    3:  ['PRW',     """ "Pw" + "Pr" >= 40 """, ""],
    4:  ['LH1',     """ (("Ab" + "Ew" + "Pb") >= 30 Or "Pb" >=40 ) """,                     """AND ("Ecosite_GeoRangeAndNumber" in ('B130', 'B131')) """],
    5:  ['TH1',     """ ("Ab" + "Ew" + "Pb") + "Mh" + ("Pl" + "_By" + "Mr") + "He" >= 30 """, ""],
    6:  ['SBOG',    """ ("Sb" + "La" + ("Ce" + "Cw") >= 70) And "OSC" = 4 """,               """AND ("Ecosite_GeoRangeAndNumber" in ('B126', 'B136', 'B137'))"""],
    7:  ['SB1',     """ ("Sb" >= 70) """,           """AND "Ecosite_GeoRangeAndNumber" in ('B126', 'B127', 'B128', 'B129', 'B222', 'B223', 'B224')"""],
    8:  ['PJ1',     """ ("Pj" >= 70) """,           """AND "Ecosite_GeoRangeAndNumber" in ('B012', 'B034', 'B035', 'B049', 'B050')"""],
    9:  ['LC1',     """ (("Ce" + "Cw") + "La" + "Sb" >= 70) """, """AND ("Ecosite_GeoRangeAndNumber" in ('B127', 'B128', 'B129', 'B222', 'B223', 'B224'))"""],
    10: ['PJ2',     """ ("Pj" + "Sb" + "Pr" >= 70 Or ("Pj" >= 50 And "Pj" + "Sb" + "Bf" + ("Sw" + "Sx") + "He" + "Pw" + "Pr" + ("Ce" + "Cw") + "La" >=70)) And "Pj" >= "Sb" """, ""],
    11: ['SP1',     """ "Sb" + ("Sw" + "Sx") + "Bf" + ("Ce" + "Cw") + "La" + "Pw" + "Pj" + "Pr" + "He" >=70 And ("Bf" + ("Ce" + "Cw") + "Pw" + "La" + ("Sw" + "Sx") + "He" <= 20 Or "Pj" >= 30) """, ""],
    12: ['SF1',     """ "Sb" + ("Sw" + "Sx") + "Bf" + ("Ce" + "Cw") + "La" + "Pw" + "Pj" + "Pr" + "He" >= 70 """, ""],
    13: ['PO1',     """ ("Po" + "Pt") + "Bw" + "Mh" + ("Pl" + "_By" + "Mr") + ("Ab" + "Ew" + "Pb") >= 70 And ("Po" + "Pt") >= 50 """, ""],
    14: ['BW1',     """ ("Po" + "Pt") + "Bw" + "Mh" + ("Pl" + "_By" + "Mr") + ("Ab" + "Ew" + "Pb") >= 70 """, ""],
    15: ['MH1',     """ (("Bf" <= 20 And ("Sw" + "Sx") <= 20 And ("Ce" + "Cw") <= 20) And ("Po" + "Pt") + "Bw" + "Mh" + ("Pl" + "_By" + "Mr") + ("Ab" + "Ew" + "Pb") >= 50) """,       """AND ("Ecosite_GeoRangeAndNumber" in ('B016', 'B019', 'B028', 'B040', 'B043', 'B055', 'B059', 'B070', 'B076'))"""],
    16: ['MC1',     """ ("Bf" <= 20 And ("Sw" + "Sx") <= 20 And ("Ce" + "Cw") <= 20) And "POLYTYPE" = 'FOR' """,          """AND ("Ecosite_GeoRangeAndNumber" in ('B012', 'B014', 'B035', 'B037', 'B050', 'B052', 'B053', 'B065', 'B067', 'B068'))"""],
    17: ['MH2',     """ ("Po" + "Pt") + "Bw" + "Mh" + ("Pl" + "_By" + "Mr") + ("Ab" + "Ew" + "Pb") >= 50 """, ""],
    18: ['MC2',     """ "POLYTYPE" = 'FOR' """, ""]

}






NER_GLSL_SFU = {

# fields required: POLYTYPE, Ecosite_GeoRangeAndNumber, (STKG or OSTKG) and (OSC or SC)

#   |Order   |SFU        |SQL                   |SQL addition if Ecosite incorporated

    1:  ['PR',     """ "Pr">=70 and "Pw"<30 """, ""],
    2:  ['PWUS4',  """ "Pw"+"Pr">=50 and "Pw">"Pr" and (("Pw"+"Pr")*"OSTKG" >=30) and ("_Or"+"OB"+"Ow") < 20 """, ""],
    3:  ['PWOR',   """ ("Pw"+"Pr"+"_Or"+"OB"+"Ow">=50) and "Pw">=("_Or"+"OB"+"Ow") and ("Pw"+"Pr"+"_Or"+"OB"+"Ow")*"OSTKG" >=30 and ("_Or"+"OB"+"Ow")>=20 """, ""],
    4:  ['PWUSC',  """ ( "Pw"+"Pr">=30 AND ("Pw"+"Pr")*"OSTKG" >=30 )  OR  ( ("Pw">="He" AND "Pw">="Sw") AND "Pw">("Ce" + "Cw") AND "Pw">="_Or" AND "Pw"+"Pr" >=30 AND ("Pw"+"Pr"+"Sw"+"He"+"_Or"+"Pj"+"Ce"+"Cw")*"OSTKG" >=30 AND ("Pw"+"Pr"+"Pj"+"Sw"+"Sb"+"Sr"+"Sx"+"He"+"Bf"+"Ce"+"Cw"+"La")>=80 ) """, ""],
    5:  ['PWUSH',  """ ( "Pw">="Pr" AND "Pw"+"Pr">=30 AND ("Pw"+"Pr")*"OSTKG" >=30 )  OR  ( "Pw">="Pr" AND "Pw">="He" AND "Pw">="Sw" AND "Pw">("Ce" + "Cw") AND "Pw">="_Or" AND ("Pw"+"Pr") >=30 AND ("Pw"+"Pr"+"Sw"+"He"+"_Or"+"Pj"+"Ce"+"Cw")*"OSTKG" >=30 AND ("Pw"+"Pr"+"Pj"+"Sw"+"Sr"+"Sx"+"Sb"+"He"+"Bf"+"Ce"+"Cw"+"La")<80 ) """, ""],
    6:  ['PWST',   """ ("PW"+"PR">=30) AND ("PW"+"PR">="HE") AND ("PW"+"PR">="SW") AND ("PW"+"PR">="SB"+"SR"+"SX") AND ("PW"+"PR">=("CE"+"CW")) AND ("PW"+"PR">="_OR") """, ""],
    7:  ['PJ1',    """ ("PJ">=70) AND ("MH"+"AB"+"AW"+"BD"+"BE"+"CH"+"EW"+"IW"+"_OR"+"_BY"+"OW"+"Ob"+"PO"+"Pt"+"Pb"+"Pl"+"BW"+"MR"+"MS"+"AX"+"CB"+"EX"+"HI"+"BN"<=20) """, ""],
    8:  ['PJ2',    """ ((("PJ"+"SB"+"SR"+"SX"+"PR">=70) OR (("PJ">=50) AND ("PJ"+"SB"+"SR"+"SX"+"BF"+"SW"+"HE"+"PW"+"PR"+"CE"+"CW"+"LA">=70) AND ("BF"+"SW"+"HE"+"PW"+"CE"+"CW"+"LA"<=20))) AND ("PJ">="SB"+"SR"+"SX")) """, ""],
    9:  ['HE',     """ "He">=40 """, ""],
    10: ['CE',     """ ("CE"+"CW">=40) AND (("CE"+"CW")>="SB"+"SR"+"SX"+"LA"+"BF") AND ("OW"+"Ob"+"EW"+"IW"+"CH"+"MH"+"AB"+"AW"+"BD"+"BE"+"_OR"+"_BY"+"PO"+"Pb"+"Pt"+"Pl"+"BW"+"MR"+"MS"+"EX"+"CB"+"AX"+"HI"+"BN"<30) """, """ AND "Ecosite_GeoRangeAndNumber" In ('G127', 'G128', 'G129', 'G222', 'G223', 'G224', 'G136', 'B127', 'B128', 'B129', 'B222', 'B223', 'B224', 'B136') """],
    11: ['SB',     """ ("SB"+"SR"+"SX">=80) AND ("MH"+"AW"+"BD"+"BE"+"CH"+"IW"+"_OR"+"OW"+"Ob"+"_BY"+"PR"+"BN"+"HI"+"CB"=0) AND ("PW"+"PJ"<=10) """, """ and "Ecosite_GeoRangeAndNumber" In ('G127', 'G128', 'G129', 'G222', 'G223', 'G224', 'G136', 'B127', 'B128', 'B129', 'B222', 'B223', 'B224', 'B136') """],
    12: ['LC',     """ ("SB"+"SX"+"SR"+"CE"+"CW"+"LA">=80) AND ("MH"+"AW"+"BD"+"BE"+"CH"+"IW"+"_OR"+"OW"+"Ob"+"_BY"+"PR"+"CB"+"HI"+"BN"=0) AND ("PW"+"PJ"<=10)  """, """AND "Ecosite_GeoRangeAndNumber" In ('G127', 'G128', 'G129', 'G222', 'G223', 'G224', 'G136', 'B127', 'B128', 'B129', 'B222', 'B223', 'B224', 'B136') """],
    13: ['SP1',    """ ("SB"+"SW"+"SR"+"SX"+"BF"+"CE"+"CW"+"LA"+"PW"+"PJ"+"PR"+"HE">=70) AND (("BF"+"CE"+"CW"+"PW"+"LA"+"SW"+"HE"<=20) OR ("PJ">=30)) """, ""],
    14: ['SF',     """ ("SW"+"SR"+"SB"+"SX"+"PW"+"PR"+"PJ"+"BF"+"CE"+"CW"+"LA"+"HE">=70) """, ""],
    15: ['BY',     """ "_By">=40 """, ""],
    16: ['OAK',    """ ("_OR">="MH"+"BE") AND ("_OR">=30) AND ("_OR"+"MH"+"AW"+"AB"+"BE"+"BD"+"_BY"+"PW"+"PR"+"SW"+"HE"+"AX">=40)  """, ""],
    17: ['HDSL2',  """ (("BD"+"AW"+"CH"+"_OR"+"OW"+"Ob"+"CB">=30) OR (("BE"+"_OR"+"OW"+"Ob">=30) OR ("BE">=20))) """, ""],
    18: ['HDSL1',  """ ("MH"+"AW"+"BD"+"BE"+"CH"+"EW"+"IW"+"_OR"+"_BY"+"OW"+"Ob"+"HE"+"EX"+"CB">=50) AND ("PO"+"Pt"+"Pb"+"Pl"+"BW"+"BF"<=30) AND ("OSC" <= 2) """, ""],
    19: ['LWMW',   """ ("CE"+"CW"+"AB"+"LA"+"SB"+"AX"+"SR"+"SX">=30) AND (("AB"+"AX">=20) OR ("AB"+"AX"+"MR"+"MS"+"_BY">=30)) """, """AND "Ecosite_GeoRangeAndNumber" In ('G071', 'G120', 'G130', 'G131', 'G132', 'G133', 'B071', 'B120', 'B130', 'B131', 'B132', 'B133') """],
    20: ['HDUS',   """ ("MH"+"AW"+"BD"+"BE"+"CH"+"EW"+"IW"+"_OR"+"_BY"+"OW"+"Ob"+"HE"+"CB"+"HI"+"EX"+"BN">=50) """, ""],
    21: ['PO',     """ ("PO"+"Pt"+"Pb"+"Pl">=50) AND ("MH"+"AB"+"AW"+"BD"+"BE"+"CH"+"EW"+"IW"+"_OR"+"_BY"+"OW"+"Ob"+"PO"+"Pb"+"Pt"+"Pl"+"BW"+"MR"+"MS"+"AX"+"BN"+"CB"+"EX"+"HI">=70) """, ""],
    22: ['BW',     """ ("PO"+"Pt"+"Pb"+"Pl"+"BW">=50) AND ("MH"+"AB"+"AW"+"BD"+"BE"+"CH"+"EW"+"IW"+"_OR"+"_BY"+"OW"+"Ob"+"PO"+"Pt"+"Pb"+"Pl"+"BW"+"MR"+"MS"+"AX"+"BN"+"CB"+"EX"+"HI">=70)  """, ""],
    23: ['MWUS',   """ (("SW"+"PW"+"PR"+"CE"+"CW"+"MH"+"_BY"+"AW"+"CH"+"BD"+"_OR"+"OW"+"Ob"+"IW"+"BE"+"HE"+"CB"+"HI"+"BN")*"OSTKG">=30) """, ""],
    24: ['MWD',    """ ("PJ"+"PW"+"PR">=20) """, ""],
    25: ['MWR',    """ "POLYTYPE" = 'FOR' """, ""]
}





if __name__ == '__main__':
    for k,v in NER_GLSL_SFU.iteritems():
        print('%s: %s'%(v[0],v[1]+v[2]))


