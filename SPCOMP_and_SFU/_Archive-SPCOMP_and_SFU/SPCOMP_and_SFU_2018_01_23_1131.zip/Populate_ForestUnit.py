#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      kimdan
#
# Note: Work to be completed:
#   1. create and populate OSC field if it doesn't exist.
#   2. create Ecosite field and populate with only the first 4 letters of Ecosite1. Done
#   3. create user interface
#-------------------------------------------------------------------------------

import arcpy
import os
from library import ForestUnit_SQL as libSQL


def main(inputfc, outputfc, forestunittype, OSCfield = "OSC", OSTKGfield = "OSTKG", useecosite = 'false'):

    # based on forest unit type, different SQL dictionary will be used
    typeLookup = { "NER Boreal SFU": "libSQL.NER_Boreal_SFU",     "NER GLSL SFU": "libSQL.NER_GLSL_SFU"}
    fuType = eval(typeLookup[forestunittype])

    # examining existing fields - Need POLYTYPE field and at least one of SC or OSC field
    arcpy.AddMessage("Checking if the input file has the mandatory fields: POLYTYPE and (OSC or SC).")
    existingFields = [str(f.name).upper() for f in arcpy.ListFields(inputfc)]

    if 'POLYTYPE' not in existingFields:
        arcpy.AddError("\nPOLYTYPE field does not exist in your input data.\n")
        raise Exception("POLYTYPE field not found in the input table.")

    # Copy the feature class to the ouput location
    arcpy.AddMessage("Copying the input the the output location...")
    outpath = os.path.split(outputfc)[0]
    outname = os.path.split(outputfc)[1]
    arcpy.FeatureClassToFeatureClass_conversion(inputfc,outpath,outname)


    # create a temporary layer file - this layer will be used for selecting and calculating field until finally being exported to a real feature class.
    arcpy.AddMessage("Creating a temporary layer...")
    arcpy.MakeFeatureLayer_management(outputfc,"templyr")


    # create a new field
    newField = forestunittype.replace(" ","_")
    if useecosite == 'true': newField = newField + "_withEcosite"

    arcpy.AddMessage("Creating a new field: %s"%newField)
    arcpy.AddField_management(in_table = "templyr", field_name = newField, field_type = "TEXT", field_length = "10")


    # If ecosite incorporated, add a field to templyr and populate it with the portion of the ecoiste used in the sql
    if useecosite == 'true':
        if 'ECOSITE1' in existingFields:
            ecositeField = "ECOSITE1"
        elif 'PRI_ECO' in existingFields:
            ecositeField = "PRI_ECO"
        else:
            arcpy.AddError("\nECOSITE1 or PRI_ECO field does not exist in your input data.\n")
            raise Exception("ECOSITE1 or PRI_ECO field not found in the input table.")

        newEcoField = 'Ecosite_GeoRangeAndNumber'
        if newEcoField not in existingFields:
            arcpy.AddField_management(in_table = 'templyr', field_name = newEcoField, field_type = "TEXT", field_length = "10")
            arcpy.SelectLayerByAttribute_management("templyr", "NEW_SELECTION", ' "' + ecositeField + '" IS NOT NULL ')
            arcpy.CalculateField_management("templyr", newEcoField, "!" + ecositeField + "![:4]", "PYTHON_9.3")


    # select by attribute and calculate field
    arcpy.AddMessage("Selecting and calculating field...")
    for k, v in sorted(fuType.iteritems(),reverse = True): ## without sorted function, the order will be incorrect.

        # if useecosite is True, incorporate ecosite in the SQL
        if useecosite == 'false':
            sql = v[1]
        else:
            sql = v[1] + v[2]

        # if custom field names are used for OSC and OSTKG
        if OSCfield not in [None,'OSC','']:
            sql = sql.replace('"OSC"', '"' + OSCfield + '"')
        if OSTKGfield not in [None,'OSTKG','']:
            sql = sql.replace('"OSTKG"', '"' + OSTKGfield + '"')

        # Select and calcualte field
        arcpy.AddMessage(v[0] + ": " + sql)
        arcpy.SelectLayerByAttribute_management("templyr", "NEW_SELECTION", sql)
        arcpy.CalculateField_management("templyr", newField, "'" + v[0] + "'", "PYTHON_9.3")


    # clear selection
    arcpy.SelectLayerByAttribute_management("templyr", "CLEAR_SELECTION")



if __name__ == '__main__':
    arcinputfc = arcpy.GetParameterAsText(0)
    arcoutputfc = arcpy.GetParameterAsText(1)
    arcforestunittype = str(arcpy.GetParameterAsText(2))
    arcOSCfield = str(arcpy.GetParameterAsText(3))
    arcOSTKGfield = str(arcpy.GetParameterAsText(4)) # not mandatory if boreal SFU
    arcuseecosite = str(arcpy.GetParameterAsText(5)) # use the parameter type "boolean" in arc tool - it will give 'true' or 'false'

    main(arcinputfc, arcoutputfc, arcforestunittype, arcOSCfield, arcOSTKGfield, arcuseecosite)

