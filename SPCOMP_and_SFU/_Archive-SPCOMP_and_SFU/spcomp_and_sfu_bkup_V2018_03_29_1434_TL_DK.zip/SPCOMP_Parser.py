#-------------------------------------------------------------------------------
# Name:         FU_Classifier
# Purpose:      This tool can be used to check the FU.
#               It makes a copy of a BMI or PCI, creates new fields for every possible species,
#               and translates the SPCOMP into species percentages.
#
# Author:      kimdan
#
# Created:     25/09/2017
# Copyright:   (c) kimdan 2017
#
#   Date        Person      Description of change
# ----------    -------     ---------------------
# 2018-03-26    littleto    Add 'SppOccurList' to list the species that actually have occurance in the
#                               inventory, and print the the ArcTool box window as a python list.
# 2018-03-26    littleto    Changes the messages to include them in a log file, and write the log file.
#                               This uses the 'print2' and 'output' functions in the 'messages' module.
#                               Add the datetime module.
# 2018-03-27    littlto     Improve robustness of the output of log to consider file geodatabases.
# 2018-03-27    littlto     Add process times for log file.
#-------------------------------------------------------------------------------

import Reference as R # Reference.py should be located in the same folder as this file.
import arcpy, os
from messages import print2
from messages import output
from datetime import datetime


### setting the workspace
##arcpy.env.workspace = os.path.split(outputfc)[0]

def spParse(inputfc,outputfc,spfield):
    # Mark start time
    starttime = datetime.now()
    msg = print2('Start of process: %(start)s.' %{'start':starttime.strftime('%Y-%m-%d %H:%M:%S')})

    # Copy the input bmi to the location of choice
    msg += print2("Making a copy of the input feature class... \n\tInput: %(infc)s\n\tOutput: %(outfc)s\n\tSpecies field: %(species_field)s" %{'infc':inputfc, 'outfc':outputfc, 'species_field':spfield})
    arcpy.FeatureClassToFeatureClass_conversion(in_features=inputfc, out_path=os.path.split(outputfc)[0], out_name=os.path.split(outputfc)[1])


    # Create a complete list of species and the corresponding list of field names

    completeSpList = R.SpcListInterp + R.SpcListOther # this is our complete species list.
    completeSpList.sort()

    completeFldList = completeSpList
    completeFldList[completeFldList.index('BY')] = '_BY'
    completeFldList[completeFldList.index('OR')] = '_OR'


    # Creating fields for each species
    existingFields = [str(f.name).upper() for f in arcpy.ListFields(outputfc)]

    for sp in completeFldList:
        if sp not in existingFields:
            msg += print2("Creating a new field: %s"%sp)
            arcpy.AddField_management(in_table = outputfc, field_name = sp, field_type = "SHORT")
        else:
            msg += print2("Creating a new field: %s - field already exists!"%sp)


    # populate zeros for all the newly created fields

    msg += print2("Populating the newly created fields with default zero...")
    with arcpy.da.UpdateCursor(outputfc, completeFldList) as cursor:
        for row in cursor:
            for i in range(len(completeFldList)):
                row[i] = 0
            cursor.updateRow(row)  ## Now all the newly populated fields are zero by default


    # Creating other fields
    fieldname = 'SPC_Check'
    completeFldList.append(fieldname)
    if fieldname not in existingFields:
        msg += print2("Creating a new field: %s"%fieldname)
        arcpy.AddField_management(in_table = outputfc, field_name = fieldname, field_type = "TEXT", field_length = "150")

    ##fieldname = "NER_FU"
    ##completeFldList.append(fieldname)
    ##if fieldname not in existingFields:
    ##    arcpy.AddMessage("Creating a new field: %s"%fieldname)
    ##    arcpy.AddField_management(in_table = outputfc, field_name = fieldname, field_type = "TEXT", field_length = "20")


    # Check SPCOMP or OSPCOMP field. if passed, populate the fields with percentages  if not passed the check, write the error message to the SPC_Check field

    completeFldList.append(spfield)

    # Record the complete list of species
    msg += print2("The complete list of species include: %s" %completeFldList)   ## Print the unique list of species with occurances in the inventory.

    SppOccurList = set()    ## Create a set to contain a unique list of species with occurances in the inventory.

    msg += print2("Populating species fields with percentage values...")
    f = completeFldList
    with arcpy.da.UpdateCursor(outputfc, f) as cursor:
        for row in cursor:
            if row[f.index(spfield)] not in [None, '', ' ']: ## if SPCOMP field is none, the spcVal function won't work
                ValResult = R.spcVal(row[f.index(spfield)],spfield) ## ValResult example: ["Pass", {'AX':60,'CW':40}]
                if ValResult[0] != "Error":
                    for k, v in ValResult[1].iteritems():
                        try:
                            row[f.index(k)] = v ## for example, k = 'AX' and v = 60
                        except:
                            row[f.index("_" + k)] = v ## for field names such as _BY

                    row[f.index(fieldname)] = "Pass"

                    SppOccurList.add(k)   ## Once the species code and value 'passes' add that species to the species occurance list.
                else:
                    row[f.index(fieldname)] = "%s: %s"%(ValResult[0], ValResult[1])
            cursor.updateRow(row)

    msg += print2("The list of species with occurances in the inventory include: %s" %list(SppOccurList))   ## Print the unique list of species with occurances in the inventory.

    # Mark end time
    endtime = datetime.now()
    msg += print2('End of process: %(end)s.' %{'end':endtime.strftime('%Y-%m-%d %H:%M:%S')})

    msg += print2('Duration of process: %(duration)s seconds.' %{'duration':(endtime - starttime).total_seconds()})


    # Write 'msg' the log file to the output folder
    ## Create the output path, considering whether or not the feature class is in a file geodatabase folder or not.
    if arcpy.Describe(outputfc[:outputfc.rfind('\\')]).dataType == 'Workspace':
        outpath = outputfc[:outputfc[:outputfc.rfind('.')].rfind('\\')]
    else:
        outpath = os.path.split(outputfc)[0]

    ## Create the output file name for the log
    outfile = os.path.split(outputfc)[1] + '_log_' + datetime.now().strftime('%Y_%m_%d_%H%M') + '.txt'

    # Create the log file.
    output(outpath, outfile, msg)

if __name__ == '__main__':
    arcinputfc = arcpy.GetParameterAsText(0) # this should be bmi or pci
    arcoutputfc = arcpy.GetParameterAsText(1) # where to save your work
    arcspfield = arcpy.GetParameterAsText(2) # 2009 or 2017

    spParse(arcinputfc,arcoutputfc,arcspfield)




